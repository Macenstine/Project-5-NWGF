function dateCalc() {

    var date = new Date();
    document.getElementById("p2").innerHTML = ("Today is: " + date);
}
