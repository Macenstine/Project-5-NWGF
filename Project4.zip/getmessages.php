<?php
    function getEmployeeByMsg($empID){
        global $db;
    $query2 = 'SELECT * FROM messageLog
                WHERE empID = :empID
                ORDER BY visitorID';
    $statement2 = $db->prepare($query2);
    $statement2->bindValue(":empID", $empID);
    $statement2->execute();
    $messageLogs = $statement2;
        
        return $messageLogs;
    }
?>